<?php

namespace App\Filament\Resources\TamuResource\Pages;

use App\Filament\Resources\TamuResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTamu extends CreateRecord
{
    protected static string $resource = TamuResource::class;
}
