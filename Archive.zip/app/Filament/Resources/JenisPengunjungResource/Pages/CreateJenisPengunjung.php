<?php

namespace App\Filament\Resources\JenisPengunjungResource\Pages;

use App\Filament\Resources\JenisPengunjungResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJenisPengunjung extends CreateRecord
{
    protected static string $resource = JenisPengunjungResource::class;
}
