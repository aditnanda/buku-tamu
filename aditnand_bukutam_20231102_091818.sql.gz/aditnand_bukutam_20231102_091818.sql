-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: aditnand_bukutam
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authentication_log`
--

DROP TABLE IF EXISTS `authentication_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authentication_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `authenticatable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authenticatable_id` bigint(20) unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `login_at` timestamp NULL DEFAULT NULL,
  `login_successful` tinyint(1) NOT NULL DEFAULT '0',
  `logout_at` timestamp NULL DEFAULT NULL,
  `cleared_by_user` tinyint(1) NOT NULL DEFAULT '0',
  `location` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authentication_log_authenticatable_type_authenticatable_id_index` (`authenticatable_type`,`authenticatable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_log`
--

LOCK TABLES `authentication_log` WRITE;
/*!40000 ALTER TABLE `authentication_log` DISABLE KEYS */;
INSERT INTO `authentication_log` VALUES (1,'App\\Models\\User',1,'182.253.116.194','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36','2023-10-16 08:05:35',0,NULL,0,'{\"ip\": \"182.253.116.194\", \"lat\": -7.2484, \"lon\": 112.7419, \"city\": \"Surabaya\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(2,'App\\Models\\User',1,'182.253.116.194','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36','2023-10-16 08:05:59',1,NULL,0,'{\"ip\": \"182.253.116.194\", \"lat\": -7.2484, \"lon\": 112.7419, \"city\": \"Surabaya\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(3,'App\\Models\\User',1,'125.167.81.255','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 OPR/102.0.0.0','2023-10-16 08:06:54',1,'2023-10-16 08:09:11',0,'{\"ip\": \"125.167.81.255\", \"lat\": -7.2729, \"lon\": 112.757, \"city\": \"Gubengairlangga\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(4,'App\\Models\\User',1,'125.167.81.255','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 OPR/102.0.0.0','2023-10-16 11:12:52',1,'2023-10-16 11:13:49',0,'{\"ip\": \"125.167.81.255\", \"lat\": -7.2729, \"lon\": 112.757, \"city\": \"Gubengairlangga\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(5,'App\\Models\\User',1,'146.75.160.31','Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1','2023-10-28 02:35:29',1,'2023-10-28 02:39:10',0,'{\"ip\": \"146.75.160.31\", \"lat\": -4.6687, \"lon\": 105.7241, \"city\": \"Surabaya\", \"state\": \"LA\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"Lampung\", \"postal_code\": \"\"}'),(6,'App\\Models\\User',1,'125.164.1.63','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1','2023-10-28 02:39:18',1,NULL,0,'{\"ip\": \"125.164.1.63\", \"lat\": -7.2484, \"lon\": 112.7419, \"city\": \"Surabaya\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(7,'App\\Models\\User',1,'36.81.138.225','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 OPR/103.0.0.0','2023-10-28 02:44:58',1,NULL,0,'{\"ip\": \"36.81.138.225\", \"lat\": -6.18104, \"lon\": 106.826, \"city\": \"Jakarta Pusat\", \"state\": \"JK\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"Jakarta\", \"postal_code\": \"\"}'),(8,'App\\Models\\User',1,'103.175.218.68','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 OPR/103.0.0.0','2023-10-29 04:45:50',1,NULL,0,'{\"ip\": \"103.175.218.68\", \"lat\": -6.20933, \"lon\": 106.821, \"city\": \"Jakarta\", \"state\": \"JK\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"Jakarta\", \"postal_code\": \"\"}'),(9,'App\\Models\\User',1,'118.99.84.63','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36','2023-10-31 01:35:25',1,NULL,0,'{\"ip\": \"118.99.84.63\", \"lat\": -7.2484, \"lon\": 112.7419, \"city\": \"Surabaya\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}'),(10,'App\\Models\\User',1,'182.1.81.92','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36','2023-10-31 07:55:44',1,'2023-10-31 07:59:42',0,'{\"ip\": \"182.1.81.92\", \"lat\": -7.2484, \"lon\": 112.7419, \"city\": \"Surabaya\", \"state\": \"JI\", \"country\": \"Indonesia\", \"default\": false, \"currency\": \"IDR\", \"iso_code\": \"ID\", \"timezone\": \"Asia/Jakarta\", \"continent\": \"Unknown\", \"state_name\": \"East Java\", \"postal_code\": \"\"}');
/*!40000 ALTER TABLE `authentication_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `breezy_sessions`
--

DROP TABLE IF EXISTS `breezy_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `breezy_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `authenticatable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authenticatable_id` bigint(20) unsigned NOT NULL,
  `panel_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `expires_at` timestamp NULL DEFAULT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `breezy_sessions`
--

LOCK TABLES `breezy_sessions` WRITE;
/*!40000 ALTER TABLE `breezy_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `breezy_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_10_01_173505_add_themes_settings_to_users_table',1),(6,'2023_10_01_174343_create_authentication_log_table',1),(7,'2023_10_01_185017_create_breezy_tables',1),(8,'2023_10_08_194404_create_tamus_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tamus`
--

DROP TABLE IF EXISTS `tamus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tamus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nomor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instansi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keperluan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `janji` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu_masuk` time DEFAULT NULL,
  `waktu_keluar` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tamus`
--

LOCK TABLES `tamus` WRITE;
/*!40000 ALTER TABLE `tamus` DISABLE KEYS */;
INSERT INTO `tamus` VALUES (1,'07','2023-10-16','Tes','ABC Corp','Kunjungan','Ya','foto/b7RIOvxCfmK7GudSFsNHX3bTL4LsgpLoyHEo2F15.jpg','15:05:14',NULL,'2023-10-16 08:05:14','2023-10-16 08:05:14'),(2,'20','2023-10-18','Dimas','Ptpn12','Janji','Tidak',NULL,'16:34:02','16:34:13','2023-10-18 09:34:02','2023-10-18 09:34:13'),(3,'54','2023-10-18','Hismouo','N12','Testing','Ya','foto/T9o0PnUHMMzrvJg6SZDLtuHAJRYJ0C0YY0arvp3Q.jpg','17:19:55','17:20:19','2023-10-18 10:19:55','2023-10-18 10:20:19'),(4,'2','2023-10-27','saya','dinas','konsultasi','Tidak',NULL,'18:56:55',NULL,'2023-10-27 11:56:55','2023-10-27 11:56:55'),(5,'04','2023-10-28','Dila coba','ABC Corp','Kunjungan','Ya','foto/5VsqH9ApqhvfnY1RoYa1u1S4i87nP1XIJS4prrCQ.jpg','09:38:30',NULL,'2023-10-28 02:38:30','2023-10-28 02:38:30'),(6,'05','2023-10-31','User Test','ABC Corp','Assessment','Ya','foto/CAdqgVQMwoGKmkFBfPWGj5iUNPcNgpXL169GArNp.png','14:54:59','14:55:35','2023-10-31 07:54:59','2023-10-31 07:55:35'),(7,'11','2023-10-31','User Test2','ABC','kunjungan','Ya','foto/qpzv6Bm1jbek0tEGOtdyrnMWSjmc4XHQJsd203Zk.png','15:00:14',NULL,'2023-10-31 08:00:14','2023-10-31 08:00:14');
/*!40000 ALTER TABLE `tamus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `theme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `theme_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','admin@gmail.com','2023-10-16 08:00:55','$2y$10$shXUAwvDHSpRWCWSJWaEies4OsB13bRXWYnqn3Ss0BMl.m7lthwZK','8aRWYzN2UJq0dTPS8R8he4nqja3zqWSz4YaNfaGXpv6ct8PjPZV1cqYwn5Fh','2023-10-16 08:00:55','2023-10-16 08:00:55','default',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'aditnand_bukutam'
--

--
-- Dumping routines for database 'aditnand_bukutam'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-02  9:18:18
